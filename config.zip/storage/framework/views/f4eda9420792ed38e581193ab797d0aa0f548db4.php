
<?php $__env->startSection('contant'); ?>
<div class="row">
    <div class="col-md-6">
        <h3>Video Lists</h3>
    </div>
    <div class="col-md-6 text-right">
    <a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/video/create')); ?>">  New Video</a> 
    </div>
</div>


<table class="table table-hover table-bordered" id="sampleTableno">
    <thead>
        <th>ID</th>
<th>Category</th>
<th>User </th>
<th>Vedio</th>
<th>Youtube Link</th>
<th>Status</th>
<th>Action</th>
</thead>
   
    <tbody>
<?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr><td><?php echo @$order->id; ?></td>
     <td><?php $gcat=App\Models\Gcategory::where('id',@$order->gcat_id)->first();?><?php echo e(@$gcat->name); ?></td>
     <td><?php echo @$order->user; ?></td>
<td style="height: 100px; width:100px; border-radius: 5px;background: #ccc;padding:5px;"><video width="100" height="100" controls>
  <source src="<?php echo e(@$order->video); ?>" type="video/mp4">
  <source src="<?php echo e(@$order->video); ?>" type="video/ogg">
  
</video></td>
    <td style="height: 100px; width:100px; border-radius: 5px;background: #ccc;padding:5px;"><?php echo @$order->ylink; ?></td>
    
   
     <td> 
    <?php if(@$order->status==1): ?>
    <a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/video/innotice/'.@$order->id)); ?>"><i class="fa fa-solid fa-toggle-on"></i></a>
    <?php else: ?>
    <a class="btn btn-dark  btn-sm"  href="<?php echo e(url('admin/video/acnotice/'.@$order->id)); ?>"><i class="fa fa-thin fa-toggle-off"></i></a>
    <?php endif; ?>
    </td> 

<td>

        <a class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit<?php echo e(@$order->id); ?>" ><i class="fa fa-edit"></i></a>
        
         <div class="modal fade bd-example-modal-lg" id="edit<?php echo e(@$order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Video Update</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
   <form action="<?php echo e(url('admin/video/update')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-group">

     <label>Category</label>
     
     <select name="Category" id="" class="form-control">
     <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if($cat->id==$order->gcat_id) echo"selected";?> value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
    </div>
<div class="form-group">
    <input type="hidden" name="id" class="form-control" value="<?php echo e($order->id); ?>" />

     <label>Upload Video</label>
     <input type="file" name="video" class="form-control" value="" />
     <span class=""> <video width="320" height="240" controls>
  <source src="<?php echo e(@$order->video); ?>" type="video/mp4">
  <source src="<?php echo e(@$order->video); ?>" type="video/ogg">
  
</video> </span>
    </div>
    <div class="form-group">
     <label>Youtube Link</label>
     <input type="text" name="ylink" class="form-control" value="" />
     <span><?php echo @$order->ylink; ?></span>
    </div>
    
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-info" value="Update" />
    </div>
    </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                
            </div>
            </div>
        </div>
        </div>
        
        <a class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this Video?');" href="<?php echo e(url('admin/video/destroy',$order->id)); ?>"><i class="fa fa-trash"></i></a>
       

</td>
 
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($video->links('pagination::bootstrap-4')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer2'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
$('#sampleTable').DataTable();
</script>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bpsacomb/admin.bpsa.com.bd/resources/views/admin/video.blade.php ENDPATH**/ ?>