
<?php $__env->startSection('contant'); ?>

<div class="row">
    <div class="col-md-6">
        <h3>COMMITTEE LISTS</h3>
    </div>
    <div class="col-md-6 text-right">
    <a class="btn btn-primary btn-sm" href="<?php echo e(url('writer/committee/create')); ?>">  Committee Create</a> 
    </div>
</div>

    

<table class="table table-hover table-bordered" id="sampleTableno">
    <thead>

<th>Serial No</th> 
<th>Comm Group</th> 
<th>PIMS ID</th>   
<th>BPSA <br> Designation</th>
<th>Name</th>
<th>Medal</th>
<th>Photo</th>
<th>Officail<br> Designation</th>
<th>Mobile Number</th>
<th>Association Year</th>
<th>Action</th>
</thead>
   
    <tbody>
<?php $__currentLoopData = $committee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>
    <td><?php echo e(@$order->serial_no); ?></td>
    <td><?php echo e(@$order->comm_group_slug); ?></td>
    <td><?php echo e(@$order->PIMS_ID); ?></td>
    <td><?php $designation=App\Models\Designation::where('id',@$order->BPSA_Designation_id)->first(); ?>
    <?php echo @$designation->name; ?></td>
    

    <td><?php echo e(@$order->Name); ?></td>
    <td><?php echo e(@$order->medal); ?></td>
    <td><img src="<?php echo e(@$order->photo); ?>" style="height: 100px; width:100px; border-radius: 5px;background: #ccc;padding:5px;"> </td>
    <td><?php echo e(@$order->Officail_Designation); ?></td>
   
    <td><?php echo @$order->Mobile_Number; ?></td>
    <td><?php echo @$order->Association_Year; ?></td>
    <td>

        <a class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit<?php echo e(@$order->id); ?>" href="#"><i class="fa fa-edit"></i></a>
        
         <!--edit start Modal -->
        <div class="modal fade bd-example-modal-lg" id="edit<?php echo e(@$order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Committee Update</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
       <form action="<?php echo e(url('writer/committee/update')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
   <div class="form-group">
     <label>Serial No</label>
     <input type="Number" name="serial_no" class="form-control" value="<?php echo e($order->serial_no); ?>" />
    </div>
    <div class="form-group">
    
     <label>Comm Group</label>
     
     <select name="comm_group_slug" id="" class="form-control">
     <option >Select One</option>
     <?php $__currentLoopData = $comm_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if($d->slug==$order->comm_group_slug) echo "selected" ?> value="<?php echo e($d->slug); ?>"><?php echo e($d->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
    </div>
    <div class="form-group">
     <label>PIMS ID</label>
      <input type="hidden" name="id" class="form-control" value="<?php echo e($order->id); ?>" />
     <input type="Number" name="PIMS_ID" class="form-control" value="<?php echo e($order->PIMS_ID); ?>" require/>
    </div>
    <div class="form-group">
    
     <label>BPSA Designation</label>
     
     <select name="BPSA_Designation_id" id="" class="form-control">
     <option >Select One</option>
     <?php $__currentLoopData = $desination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if($d->id==$order->BPSA_Designation_id) echo"selected";?> value="<?php echo e($d->id); ?>"><?php echo e($d->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
    </div>
    <div class="form-group">
     <label>Name</label>
     <input type="text" name="Name" class="form-control" value="<?php echo e($order->Name); ?>" require/>
    </div>
    <div class="form-group">
     <label>Medal</label>
     <input type="text" name="medal" class="form-control" value="<?php echo e($order->medal); ?>" require/>
    </div>
    <div class="form-group">
     <label>Photo</label>
     <input type="file" name="photo" class="form-control" value="" require/>
     <span><img src="<?php echo e(@$order->photo); ?>" style="height: 100px; width:100px;" alt="Responsive image"></span>
    </div>
    <div class="form-group">
     <label>Officail Designation</label>
     <input type="text" name="Officail_Designation" class="form-control" value="<?php echo e($order->Officail_Designation); ?>"  require/>
    </div>
    <div class="form-group">
     <label>Mobile Number</label>
     <input type="text" name="Mobile_Number" class="form-control" value="<?php echo e($order->Mobile_Number); ?>" require />
    </div>
    <div class="form-group">
     <label>Association Year</label>
     <input type="text" name="Association_Year" class="form-control" value="<?php echo e($order->Association_Year); ?>" require />
    </div>
    
    
   
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-info" value="Submit" />
    </div>
    </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                
            </div>
            </div>
        </div>
        </div>
         <!--edit end Modal -->
        
        <a class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this committee?');" href="<?php echo e(url('writer/committee/destroy/'.@$order->id)); ?>"><i class="fa fa-trash"></i></a>
        
       

</td>
    

 
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($committee->links('pagination::bootstrap-4')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer2'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
$('#sampleTable').DataTable();
</script>





    

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.writer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bpsacomb/admin.bpsa.com.bd/resources/views/writer/committe.blade.php ENDPATH**/ ?>