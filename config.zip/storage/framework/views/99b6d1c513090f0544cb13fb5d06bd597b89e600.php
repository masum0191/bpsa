
<?php $__env->startSection('contant'); ?>
<p class=" text-center text-info h4 "><i>Gallery Lists</i></p>
<a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/gallery/create')); ?>"> 
     New Gallery</a> 

<table class="table table-hover table-bordered" id="sampleTableno">
    <thead>



    
<th>Category</th>
<th>Title</th>
<th>Description</th>

<th>Image</th>
<th>Home Page</th>
<th>User </th>
<th>Action</th>
</thead>
   
    <tbody>
<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>

    <td><?php $gcat=App\Models\Gcategory::where('id',@$order->gcat_id)->first();?><?php echo e(@$gcat->name); ?></td>
    

    <td><?php echo e(@$order->title); ?></td>
    <td><?php echo @$order->description; ?></td>
   
    <td><img src="<?php echo e(@$order->image); ?>" style="height: 100px; width:100px; border-radius: 5px;background: #ccc;padding:5px;" alt="Responsive image"></td>
    <td> 
    <?php if(@$order->home_page==1): ?>
    <a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/gallery/innotice/'.@$order->id)); ?>"><i class="fa fa-solid fa-toggle-on"></i></a>
    <?php else: ?>
    <a class="btn btn-dark  btn-sm"  href="<?php echo e(url('admin/gallery/acnotice/'.@$order->id)); ?>"><i class="fa fa-thin fa-toggle-off"></i></a>
    <?php endif; ?>
    </td> 
<td><?php echo @$order->user; ?></td>
<td>

        <a class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit<?php echo e(@$order->id); ?>" ><i class="fa fa-edit"></i></a>
        <div class="modal fade bd-example-modal-lg" id="edit<?php echo e(@$order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Gallery Update</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
  <form action="<?php echo e(url('admin/gallery/update/')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-group">
<input type="hidden" name="id" class="form-control" value="<?php echo e($order->id); ?>" />
     <label>Category</label>
     
     <select name="Category" id="" class="form-control">
     <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if($cat->id==$order->gcat_id) echo"selected";?> value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
    </div>
    <div class="form-group">
     <label>title</label>
     <input type="text" name="title" class="form-control" value="<?php echo e($order->title); ?>" require/>
    </div>
    <div class="form-group">
     <label>Description</label>
     <textarea name="description" id="txtEditorh" class="form-control textarea2" ><?php echo $order->description; ?></textarea>
    </div>
    
    
    <div class="form-group">
     <label>Image </label>
     <input type="file" name="image" class="form-control" value="" />
     <span><img src="<?php echo e(@$order->image); ?>" style="height: 100px; width:100px;" alt="Responsive image"></span>
    </div>
    <
        
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-info" value="Submit" />
    </div>
    </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                
            </div>
            </div>
        </div>
        </div>
        
        <a class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this gallery?');" href="<?php echo e(url('admin/gallery/destroy/'.@$order->id)); ?>"><i class="fa fa-trash"></i></a>
        
       

</td>
 
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($images->links('pagination::bootstrap-4')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer2'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
$('#sampleTable').DataTable();
</script>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bpsaweb/public_html/admin.bpsa.com.bd/resources/views/admin/gallery.blade.php ENDPATH**/ ?>