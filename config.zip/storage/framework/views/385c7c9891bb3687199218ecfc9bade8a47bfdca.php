;
<?php $__env->startSection('contant'); ?>
<p class=" text-center text-info h4 "><i>Blog Lists</i></p>


<table class="table table-hover table-bordered" id="sampleTable">
    <thead>


<th>Image</th>
<th>Blog Name</th>
<th>Description</th>
<!--<th>Action</th>-->
</thead>
   
    <tbody>
<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>
<td><img src="<?php echo e(@$order->image); ?>" style="height: 100px; width:100px;" alt="Responsive image"></td>
    <td><?php echo e(@$order->title); ?></td>
    <td><?php echo e(@$order->description); ?></td>
    


 
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer2'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>





<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
if ("<?php echo e(session('status')); ?>") {
    swal("<?php echo e(session('status')); ?>");
    
}
    

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bpsacomb/admin.bpsa.com.bd/resources/views/admin/blog.blade.php ENDPATH**/ ?>