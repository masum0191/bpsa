
<?php $__env->startSection('contant'); ?>
<div class="" >

<p class="h5">Committee Create</p>

<form action="<?php echo e(url('admin/committee/store')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
    <div class="form-group">
     <label>Serial No</label>
     <input type="Number" name="serial_no" class="form-control" value="" require/>
    </div>
    <div class="form-group">
    
     <label>Comm Group</label>
     
     <select name="comm_group_slug" id="" class="form-control">
     <option >Select One</option>
     <?php $__currentLoopData = $comm_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($d->slug); ?>"><?php echo e($d->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
    </div>
    <div class="form-group">
     <label>PIMS ID</label>
     <input type="Number" name="PIMS_ID" class="form-control" value="" require/>
    </div>
    <div class="form-group">
    
     <label>BPSA Designation</label>
     
     <select name="BPSA_Designation_id" id="" class="form-control">
     <option >Select One</option>
     <?php $__currentLoopData = $desination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($d->id); ?>"><?php echo e($d->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
    </div>
    <div class="form-group">
     <label>Name</label>
     <input type="text" name="Name" class="form-control" value="" require/>
    </div>
     <div class="form-group">
     <label>Medal</label>
     <input type="text" name="medal" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>Photo</label>
     <input type="file" name="photo" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>Officail Designation</label>
     <input type="text" name="Officail_Designation" class="form-control" value=""  require/>
    </div>
    <div class="form-group">
     <label>Mobile Number</label>
     <input type="text" name="Mobile_Number" class="form-control" value="" require />
    </div>
    <div class="form-group">
     <label>Association Year</label>
     <select name="Association_Year" id="" class="form-control" require>
     <option >Select One</option>
     <?php $__currentLoopData = $session; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($s->session); ?>"><?php echo e($s->session); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
   
    </div>
    
    
   
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-info" value="Submit" />
    </div>
    </form>
</div>





    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="pull-right">
        
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bpsacomb/admin.bpsa.com.bd/resources/views/admin/create_committe.blade.php ENDPATH**/ ?>