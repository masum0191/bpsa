
<?php $__env->startSection('contant'); ?>
<div class="" >

<p class="h5">Posts</p>

<form action="<?php echo e(url('admin/post/store')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-group">
    
     <label>Category</label>
     
     <select name="Category" id="" class="form-control">
     <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
    </div>
    <div class="form-group">
     <label>Heading</label>
     <input type="text" name="Heading" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>Sub_Heading</label>
     <textarea name="Sub_Heading" id="txtEditorh" class="form-control textarea2" require></textarea>
    </div>
    <div class="form-group">
     <label>Start Date</label>
     <input type="date" name="Start_Date" class="form-control" value=""  require/>
    </div>
    <div class="form-group">
     <label>End Date</label>
     <input type="date" name="End_Date" class="form-control" value="" require />
    </div>
    <div class="form-group">
     <label>Details</label>
     <textarea name="Details" class="form-control textarea" id="txtEditor"></textarea>
    </div>
    <div class="form-group">
     <label>Cover Photo</label>
     <input type="file" name="Cover_Photo" class="form-control" value="" />
    </div>
    <div class="form-group">
     <label>Document Link</label>
     <input type="file" name="Document_Link" class="form-control" value="" />
    </div>
    <div class="form-group">
     <label>Image ( Multiple Image )</label>
     <input type="file" name="gimage[]" class="form-control" value="" multiple/>
    </div>
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-info" value="Submit" />
    </div>
    </form>
</div>





    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bpsaweb/public_html/admin.bpsa.com.bd/resources/views/admin/create_post.blade.php ENDPATH**/ ?>