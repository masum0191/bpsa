
<?php $__env->startSection('contant'); ?>
<div class="" >

<p class="h5">Massege Create</p>

<form action="<?php echo e(url('admin/massege/store')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
    <div class="form-group">
     <label>Session</label>
     <input type="text" name="session" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>Name</label>
     <input type="text" name="name" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>BPSA Designation</label>
     <input type="text" name="BPSA_Designation" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>Official designation</label>
     <input type="text" name="Official_designation" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>Note</label>
     <textarea name="note" id="txtEditorh" class="form-control textarea" ></textarea>
    </div>
   
    <div class="form-group">
     <label>Photo </label>
     <input type="file" name="photo" class="form-control" value="" />
    </div>
    
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-info" value="Submit" />
    </div>
    </form>
</div>





    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

   


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bpsaweb/public_html/admin.bpsa.com.bd/resources/views/admin/create_massege.blade.php ENDPATH**/ ?>