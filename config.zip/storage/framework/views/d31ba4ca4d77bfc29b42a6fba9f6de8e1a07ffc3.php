
<?php $__env->startSection('contant'); ?>
<div class="" >

<p class="h5">Former Update</p>

<form action="<?php echo e(url('admin/former/store/')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-group">

     <label>Session</label>
      <input type="text" name="Session" class="form-control" value="" require/>
     
    </div>
    <div class="form-group">
     <label>President Name</label>
     <input type="text" name="President_Name" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>President Designation</label>
     <input type="text" name="President_Designation" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>President Image</label>
     <input type="file" name="President_Image" class="form-control" value="" />
     
    </div>
   
   <div class="form-group">
     <label>Secretary Name</label>
     <input type="text" name="Secretary_Name" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>Secretary Designation</label>
     <input type="text" name="Secretary_Designation" class="form-control" value="" require/>
    </div>
    <div class="form-group">
     <label>Secretary Image</label>
     <input type="file" name="Secretary_Image" class="form-control" value="" />
     
    </div>
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-info" value="Submit" />
    </div>
    </form>
</div>





    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    


<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer2'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">

        $("#sampleTable").DataTable();
        
</script>





<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
if ("<?php echo e(session('status')); ?>") {
    swal("<?php echo e(session('status')); ?>");
    
}
    

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bpsaweb/public_html/admin.bpsa.com.bd/resources/views/admin/create_former.blade.php ENDPATH**/ ?>