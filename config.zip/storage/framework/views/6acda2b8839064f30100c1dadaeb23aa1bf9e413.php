
<?php $__env->startSection('contant'); ?>
<p class=" text-center text-info h4 "><i>Successes Lists</i></p>
<a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/successe/create')); ?>"> 
     New successes</a> 

<table class="table table-hover table-bordered" id="sampleTable">
    <thead>



<th>ID</th>
<th>User</th>
<th>Title</th>
<th>Note</th>

<th>Image</th>
<th>Status</th>
<th>Action</th>
</thead>
   
    <tbody>
<?php $__currentLoopData = $massege; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>

   <td><?php echo @$order->id; ?></td>
    
<td><?php echo @$order->user; ?></td>
    <td><?php echo e(@$order->title); ?></td>
    <td><?php echo @$order->note; ?></td>
   
    <td><img src="<?php echo e(@$order->image); ?>"style="height: 100px; width:100px; border-radius: 5px;background: #ccc;padding:5px;" alt="Responsive image"></td>
    <td> 
    <?php if(@$order->status==1): ?>
    <a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/successe/innotice/'.@$order->id)); ?>"><i class="fa fa-solid fa-toggle-on"></i></a>
    <?php else: ?>
    <a class="btn btn-dark  btn-sm"  href="<?php echo e(url('admin/successe/acnotice/'.@$order->id)); ?>"><i class="fa fa-thin fa-toggle-off"></i></a>
    <?php endif; ?>
    </td> 

<td>

        <a class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit<?php echo e(@$order->id); ?>" ><i class="fa fa-edit"></i></a>
        
        
        <div class="modal fade bd-example-modal-lg" id="edit<?php echo e(@$order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Committee Update</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
      <form action="<?php echo e(url('admin/successe/update/')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

    <div class="form-group">
        <input type="hidden" name="id" class="form-control" value="<?php echo e($order->id); ?>" />
     <label>Title</label>
     <input type="text" name="title" class="form-control" value="<?php echo e($order->title); ?>" require/>
    </div>
    <div class="form-group">
     <label>Note</label>
     <textarea name="note" id="txtEditorh" class="form-control " maxlength="500" ><?php echo $order->note; ?></textarea>
    </div>
    
    
    <div class="form-group">
     <label>Photo </label>
     <input type="file" name="photo" class="form-control" value="" />
     <span><img src="<?php echo e(@$order->image); ?>" style="height: 100px; width:100px;" alt="Responsive image"></span>
    </div>
    <
        
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-info" value="Submit" />
    </div>
    </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                
            </div>
            </div>
        </div>
        </div>
        
        <a class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this Successe?');" href="<?php echo e(url('admin/successe/destroy/'.@$order->id)); ?>"><i class="fa fa-trash"></i></a>
        
       

</td>
 
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer2'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>








<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bpsacomb/admin.bpsa.com.bd/resources/views/admin/successe.blade.php ENDPATH**/ ?>