
<?php $__env->startSection('contant'); ?>
<div class="row">
    <div class="col-md-6">
        <h3>Slider Lists</h3>
    </div>
    <div class="col-md-6 text-right">
    <a class="btn btn-primary btn-sm" href="<?php echo e(route('slider.create')); ?>">  New Slider</a> 
    </div>
</div>


<table class="table table-hover table-bordered" id="sampleTableno">
    <thead>

<th>User </th>
<th>Image</th>
<th>Title</th>
<th>Description</th>
<th>Status</th>
<th>Action</th>
</thead>
   
    <tbody>
<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>
    <td><?php echo @$order->user; ?></td>
<td><img src="<?php echo e(@$order->image); ?>" style="height: 100px; width:100px; border-radius: 5px;background: #ccc;padding:5px;" alt="Responsive image"></td>
    <td><?php echo e(@$order->title); ?></td>
    <td><?php echo e(@$order->description); ?></td>
    <td> 
    <?php if(@$order->status==1): ?>
    <a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/slider/innotice/'.@$order->id)); ?>"><i class="fa fa-solid fa-toggle-on"></i></a>
    <?php else: ?>
    <a class="btn btn-dark  btn-sm"  href="<?php echo e(url('admin/slider/acnotice/'.@$order->id)); ?>"><i class="fa fa-thin fa-toggle-off"></i></a>
    <?php endif; ?>
    </td> 
    

<td>

        <a class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit<?php echo e(@$order->id); ?>" ><i class="fa fa-edit"></i></a>
        
        <div class="modal fade bd-example-modal-lg" id="edit<?php echo e(@$order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Slider Update</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
      <form action="<?php echo e(url('admin/slider/update')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-group">
    <input type="hidden" name="id" class="form-control" value="<?php echo e($order->id); ?>" />

     <label>Image</label>
     <input type="file" name="image" class="form-control" value="" />
     <span class=""> <img src="<?php echo e(@$order->image); ?>" alt="" hieght="150px" width="150px"> </span>
    </div>
    <div class="form-group">
     <label>Title</label>
     <input type="text" name="title" class="form-control" value="<?php echo e($order->title); ?>" />
    </div>
    <div class="form-group">
     <label>Description</label>
     <textarea name="description" class="form-control textarea" value=""><?php echo e($order->description); ?></textarea>
    </div>
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-info" value="Update" />
    </div>
    </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                
            </div>
            </div>
        </div>
        </div>
        <a class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this Slider?');" href="<?php echo e(url('admin/slider/destroy',$order->id)); ?>"><i class="fa fa-trash"></i></a>
       

</td>
 
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($images->links('pagination::bootstrap-4')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer2'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
$('#sampleTable').DataTable();
</script>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bpsacomb/dev.bpsa.com.bd/resources/views/admin/slider.blade.php ENDPATH**/ ?>