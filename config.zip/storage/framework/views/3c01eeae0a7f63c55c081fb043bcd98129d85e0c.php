
<?php $__env->startSection('contant'); ?>
<div class="" >

<p class="h5">Posts Update</p>

<form action="<?php echo e(url('admin/post/update/')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-group">
<input type="hidden" name="id" class="form-control" value="<?php echo e($post->id); ?>" />
     <label>Category</label>
     
     <select name="Category" id="" class="form-control">
     <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if($cat->name==$post->Category) echo"selected";?> value="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?> </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
    </div>
    <div class="form-group">
     <label>Heading</label>
     <input type="text" name="Heading" class="form-control" value="<?php echo e($post->Heading); ?>" require/>
    </div>
    <div class="form-group">
     <label>Sub_Heading</label>
     <textarea name="Sub_Heading" id="txtEditorh" class="form-control textarea2" require><?php echo $post->Sub_Heading; ?></textarea>
    </div>
    <div class="form-group">
     <label>Start Date</label>
     <input type="date" name="Start_Date" class="form-control" value="<?php echo e($post->Start_Date); ?>"  require/>
    </div>
    <div class="form-group">
     <label>End Date</label>
     <input type="date" name="End_Date" class="form-control" value="<?php echo e($post->End_Date); ?>" require />
    </div>
    <div class="form-group nopadding">
     <label>Details</label>
     <textarea name="Details" class="form-control textarea" id="txtEditor"><?php echo $post->Details; ?></textarea>
    </div>
    <div class="form-group">
     <label>Cover Photo</label>
     <input type="file" name="Cover_Photo" class="form-control" value="" />
     <span><img src="<?php echo e(@$post->Cover_Photo); ?>" style="height: 100px; width:100px;" alt="Responsive image"></span>
    </div>
    <div class="form-group">
     <label>Document Link</label>
     <input type="file" name="Document_Link" class="form-control" value="" />
     <span> <a class="" href="<?php echo e(@$post->Document_Link); ?>"><?php echo e(@$post->Document_Link); ?></a></span>
    </div>
    <div class="form-group">
     <label>Image ( Multiple Image )</label>
     <input type="file" name="gimage[]" class="form-control" value="" multiple/>
     <div class="modal-body">
            <?php if($post->gimage): ?>
            <ul class="nav nav-tabs" role="tablist">
          
            <?php $gellary= json_decode($post->gimage);?>
                                    <?php $__currentLoopData = $gellary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a class="example-image-link nav-link active" href="<?php echo e(asset('uploads/post/'.$g)); ?>"
                                            data-lightbox="example-set"
                                            data-title="Click the right half of the image to move forward."><img
                                                class="example-image" src="<?php echo e(asset('uploads/post/'.$g)); ?>" alt=""
                                                style="width:100%; height:110px;" /></a>

                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </ul>
            <?php else: ?>
            <p>No Gallery</p>
            <?php endif; ?>
            </div>
     <span></span>
    </div>
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-info" value="Submit" />
    </div>
    </form>
</div>





    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\BPSA-dev\Admin_Panel_Full_20240216\resources\views/admin/edit_post.blade.php ENDPATH**/ ?>