<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@creativeitbari">
    <meta property="twitter:creator" content="@Hasibuzzaman">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title>Writer || BPSA</title>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/login/css/main.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/editor.css')); ?>">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/summernote/summernote-bs4.min.css')); ?>">
    <link rel="icon" href="<?php echo e('assets/images/images.jpg'); ?>" type="image/gif" sizes="16x16">
  </head>
  <body class="app sidebar-mini rtl">
      
      <header class="app-header"><a class="app-header__logo" href="<?php echo e(url('/admin/home')); ?>">BPSA </a>
        <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="<?php echo e(url('/')); ?>" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
        <!-- Navbar Right Menu-->
        <ul class="app-nav">
          <li class="app-search">
            <input class="app-search__input" type="search" placeholder="Search">
            <button class="app-search__button"><i class="fa fa-search"></i></button>
          </li>
          <!--Notification Menu-->
         
          <!-- User Menu-->
          <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
            <ul class="dropdown-menu settings-menu dropdown-menu-right">
             
              <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-sign-out fa-lg"></i> Logout</a>                              
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>
               </li>
            </ul>
          </li>
        </ul>
      </header>
      
      <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      
        <div>
          <p class="app-sidebar__user-name"><?php echo e(Auth::user()->name); ?></p>
          <p class="app-sidebar__user-designation"><?php echo e(Auth::user()->email); ?></p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item  <?php echo e((request()->is('writer/home')) ? 'active' : ''); ?>" href="/writer/home"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
      
         <li><a class="app-menu__item <?php echo e((request()->is('writer/committee')) ? 'active' : ''); ?>" href="<?php echo e(url('writer/committee')); ?>"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Committee</span></a></li>
        <li><a class="app-menu__item <?php echo e((request()->is('writer/post')) ? 'active' : ''); ?>" href="<?php echo e(url('writer/post')); ?>"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Post</span></a></li>
        
        <li><a class="app-menu__item <?php echo e((request()->is('writer/gallery')) ? 'active' : ''); ?>" href="<?php echo e(url('writer/gallery')); ?>"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Gallery</span></a></li>
        

      </ul>
    </aside>
   
    
    <main class="app-content tile">
    <?php echo $__env->yieldContent('contant'); ?>
</main>
    
    <!-- Essential javascripts for application to work-->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
            <!-- <script src="<?php echo e(asset('assets/login/js/jquery-3.2.1.min.js')); ?>"></script> -->
            <script src="<?php echo e(asset('assets/login/js/popper.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/login/js/bootstrap.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/login/js/main.js')); ?>"></script>
            <!-- The javascript plugin to display page loading on top-->
            <script src="<?php echo e(asset('assets/login/js/plugins/pace.min.js')); ?>"></script>
 	<!-- Summernote -->
    	<script src="<?php echo e(asset('assets/summernote/summernote-bs4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/editor.js')); ?>"></script>
            <!-- Page specific javascripts-->
            <script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/chart.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/bootstrap-notify.min.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/sweetalert.min.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/moment.min.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/jquery-ui.custom.min.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('assets/login/js/plugins/fullcalendar.min.js')); ?>"></script>

	<script>
			$(document).ready(function() {
        
        $('.textarea').richText();
        $('.textarea2').richText();
			
			});
		</script>
    <script>
if ("<?php echo e(session('status')); ?>") {
    swal("<?php echo e(session('status')); ?>");
    
}
	</script>
    

    <?php echo $__env->yieldContent('footer2'); ?>
    
    

    <?php echo $__env->yieldContent('extra'); ?>

</body>
</html><?php /**PATH /home/bpsacomb/admin.bpsa.com.bd/back-end/admin/resources/views/layouts/writer.blade.php ENDPATH**/ ?>