<?php

namespace App\Http\Controllers;

use App\Models\Qlink;
use Illuminate\Http\Request;

class QlinkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Qlink  $qlink
     * @return \Illuminate\Http\Response
     */
    public function show(Qlink $qlink)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Qlink  $qlink
     * @return \Illuminate\Http\Response
     */
    public function edit(Qlink $qlink)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Qlink  $qlink
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Qlink $qlink)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Qlink  $qlink
     * @return \Illuminate\Http\Response
     */
    public function destroy(Qlink $qlink)
    {
        //
    }
}
